#include <iostream>

using namespace std;
class calculator
{
private:
    int a,b;

public:
    void getData();
    void add();
    void subtract();

};

void calculator::getData()
{
    cout<<"Enter two numbers: ";
    cin>>a>>b;
}

void calculator::add()
{
    cout<<"Addition = "<< a+b<<endl;
}

void calculator::subtract()
{
    cout<<"Subtraction =" <<a-b<<endl;
}
int main()
{
calculator c;

c.getData();
c.add();
c.subtract();

    return 0;
}
