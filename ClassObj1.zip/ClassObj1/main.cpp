#include <iostream>

using namespace std;
class student
{
private:
    string name;
    int age;
    float marks;

public:
    void getdata();
    void displaydata();


};
void student::getdata()
{
    cout<<"Enter your name: ";
    cin>>name;
    cout<<"Enter your age: ";
    cin>>age;
    cout<<"Enter marks: ";
    cin>>marks;
}
void student::displaydata()
{

    cout<<"*********Student Information**********"<<endl;
    cout<<"Name: "<<name<<endl;
    cout<<"Age: "<<age<<endl;
    cout<<"Marks: "<<marks<<endl;
}

int main()
{
    student s1;
    s1.getdata();
    s1.displaydata();
    endl;
    student s2;
    s2.getdata();
    s2.displaydata();
    return 0;
}
