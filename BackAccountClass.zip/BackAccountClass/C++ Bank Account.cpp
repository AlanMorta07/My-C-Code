#include <iostream>

using namespace std;
class bank
{
private:
    int accountNo;
    string name;
    double balance;

public:
    void input();
    void deposit();
    void withdraw();
    void display();
};
void bank::input()
{
    cout<<"Enter account number: ";
    cin>>accountNo;

    cout<<"Enter account holder name: ";
    cin>>name;

    cout<<"Enter initial balance: ";
    cin>>balance;
}
void bank::deposit()
{
    double amount;

    cout<<"Enter deposit amount: ";
    cin>>amount;

    if (amount>0)
    {
        balance = balance+amount;
        cout<<"Amount deposited successfully."<<endl;
    }
    else
        {
        cout<<"Invalid amount."<<endl;
    }
}
    void bank::withdraw()
    {
        double amount;
        cout<<"Enter withdrawal amount: ";
        cin>> amount;
        if(amount >0 &&amount <= balance)
        {
            balance = balance - amount;
            cout<<"Amount withdrawn successfully."<<endl;

        }
        else
        {
            cout<<"insuficient balance or invalid amount." <<endl;
        }
    }
    void bank::display()
    {
        cout<<"\nAccount Number: "<<accountNo;
        cout<<"\nAccount Holder: " <<name;
        cout<<"\nAvailable Balance:"<< balance <<endl;
    }
int main()
{
    bank b;
    b.input();
    b.deposit();
    b.withdraw();
    b.display();

    return 0;
}
